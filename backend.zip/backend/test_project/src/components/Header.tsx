import React from 'react';

export default function Header() {
  return (
    <header className="main-header">
      <h1 className="header-title">Test Project</h1>
    </header>
  );
}
